<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Splendorous
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130517

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="app-base" content="<?php echo e(request()->getBaseUrl()); ?>" />
<meta name="keywords" content="Nursadul Mamun, Mamun UTD, Mamun CUET, Nursadul Mamun University of Texas at Dallas, Cochlear Implant Processing Laboratory, Biomedical Engineering, Electrical Engineering, PhD,
Speech Enhancement, Auditory Nerve Modeling, Cochlear Implants and Hearing aids, Speech and Speaker Recognition, Deep neural networks in speech recognition, Speech Intelligibility and Quality measure, Machine Learning and Artificial Intelligence,Helping hearing-disabled, Texas, Research Assistant, Teaching Assistant, Scholar, Assistant Professor, Chittagong University of Engineering & Technology" />
<meta name="description" content="Electrical Engineer, Assistant Professor of Chittagong University of Engineering & Technology (Bangladesh), passionate about Speech Enhancement, Speech Intelligibility Prediction metric, Speech and Speaker Identification, working as a Research Assistant in the Cochlear Implant LAb at UTD towards a PhD in Computer Engineering, ." />
<title>Nursadul Mamun</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700|Bree+Serif" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('style.css')); ?>?v=<?php echo e(filemtime(public_path('style.css'))); ?>" rel="stylesheet" type="text/css" media="screen" />
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>
<body>
<?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><script data-page="app" type="application/json"><?php echo json_encode($page, JSON_HEX_TAG); ?></script><div id="app"></div><?php } ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/app.blade.php ENDPATH**/ ?>